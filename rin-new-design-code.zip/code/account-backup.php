<?php include_once 'header-account.php'; ?>
<!--*************CONTENT PART START*************-->
<div id="content">
	<section id="product">
		<div class="container mobileContainerFullWidth">
			<!--CUSTOMER ACCOUNT DETAIL PAGE START-->
			<div id="customerAccount">
				<div class="accountWra	pper">
					<div class="container">
					<!--CUSTOMER-ACCOUNT-HEADER START-->
						<div class="row">
							<div class="col-lg-7 col-md-7">
								<div class="customerName">
									<span class="firstLetter">a</span>
									<div class="nameEmail">
										<b>Ajay Kumar Gupta</b>
										<span class=userEmail>ajay.gupta@canbrand.in</span>
									</div>
								</div>
							</div>
							<div class="col-lg-5 col-md-5">
								<div class="rewardsBtn">
									<button>
										<b>InstaRewardz</b>
										<span>Review &amp; Redeem Rewards</span>
									</button>
								</div>
							</div>
						</div>
					<!--CUSTOMER-ACCOUNT-HEADER END-->
					<!--CUSTOMER-ACCOUNT-BODY START-->
						<div class="row tabView-account">
							<ul class="col-lg-12 nav nav-pills acntDetails">
							    <li class="active">
							    	<a data-toggle="pill" href="#history">transaction history</a>
							    </li>
							    <li><a data-toggle="pill" href="#profile">profile</a></li>
							    <li><a data-toggle="pill" href="#password">change password</a></li>
							    <li><a data-toggle="pill" href="#sup">support</a></li>
							    <!-- <li><a data-toggle="pill" href="#escalate">escalate</a></li> -->
							    <li><a data-toggle="pill" href="#help" class="change-pass">help</a></li>
							</ul>
							<div class="rchrghisWrapper tab-content">
								<div id="history" class="tab-pane fade in active">
									<ul class="col-lg-6">
										<li class="rechargeHistory activeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/docomo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="fail"><i class="fa fa-times" aria-hidden="true"></i> Fail</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/docomo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/Vodafone-Logo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Order Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">07th Aug'16, 00.15</span>
											</div>
											<div class="status">
												<b>&#8377; 700</b>
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
											</div>
										</li>
									</ul>
									<div class="col-lg-6 highlighted-Tab">
										<div class="indvidualDetails">
											<ul>
												<li><button class="ticket"><i class="fa fa-ticket" aria-hidden="true"></i>open support ticket</button></li>
												<li><button><i class="fa fa-repeat" aria-hidden="true"></i>repeat recharge</button></li>
												<li><button><i class="fa fa-print" aria-hidden="true"></i>print receipt</button></li>
											</ul>
											<!--HISTORY DETAILS-->
											<table>
												<tr>
													<td>Service</td><td class="bold">Mobile</td>
												</tr>
												<tr>
													<td>Service Type</td><td class="bold">Mobile/Mobile Data</td>
												</tr>
												<tr>
													<td>Plan Type</td><td class="bold">Top-up</td>
												</tr>
												<tr>
													<td>Circle</td><td class="bold">Delhi NCR</td>
												</tr>
												<tr>
													<td>Mobile no./Subscriber ID</td><td class="bold">7065196404</td>
												</tr>
												<tr>
													<td>Operator</td><td class="bold">Airtel</td>
												</tr>
												<tr>
													<td>Recharge/Bill pay amount</td><td class="bold">280</td>
												</tr>
												<tr>
													<td>Convenience Fee* <span>(for partner discount coupon)</span></td><td class="bold">15</td>
												</tr>
												<tr>
													<td>Paid By</td><td class="bold">Credit Card</td>
												</tr>
												<tr>
													<td>Payment Option</td><td class="bold">Visa Debit Card</td>
												</tr>
												<tr>
													<td>Pyment Gateway</td><td class="bold">PayU</td>
												</tr>
												<tr>
													<td>Operator Transaction ID</td><td class="bold na">N/A</td>
												</tr>
												<tr>
													<td>Pyment Gateway transaction ID</td><td class="bold">5982456635</td>
												</tr>
												<tr>
													<td>Coupon Face Value</td><td class="bold na">N/A</td>
												</tr>
												<tr>
													<td>Coupon FAmount Redeemed</td><td class="bold na">N/A</td>
												</tr>
												<tr>
													<td>Recharge/Bill Pay Status</td><td class="bold na">N/A</td>
												</tr>
												<tr>
													<td>Revised Recharge Status</td><td class="bold na">N/A</td>
												</tr>
												<tr>
													<td>Remarks</td><td class="bold na">N/A</td>
												</tr>
											</table>
											<!--OPEN SUPPORT TICKET-->
											<div class="contactPage customeSelect selectWithLabel mobSelectMbd" id="open-support">
												<p>
													You may escalate your issue if it remains unresolved for more than 7 days. Please note that you can escalate only after 7 days of your transaction date.
												</p>
												<form class="escalate-form">
													<div class="userSecondInput">
														<div class="form_with-submit planBrowse newclass readonly-box">
															<div class="operator selectService position_rel escalate-subject">
																<label>Choose Subject</label>
															  	<button class="dropdown_button dropdown-toggle" type="button" id="selectService" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
															    Select
															    	<img src="assets/img/down-arrow.png">
																</button>
																<ul class="dropdown-menu animated fadeIn" aria-labelledby="selectService">
																	<li><a href="javascript:void(0)" data-value="action">Escalation</a></li>
																	<li><a href="javascript:void(0)" data-value="another action">Payment not Updated</a></li>
																	
																</ul>
															</div>
							                                <div class="group">
							                                    <input type="text" required="" name="name" value="Ajay Gupta" readonly="readonly">
							                                    <label class="floatingLabel">name</label>
							                                </div>
							                                <div class="group">
							                                   	<input type="text" required="" name="number" readonly="readonly" value="7065196404">
							                                   	<label class="floatingLabel">contact mobile number</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="" readonly="readonly" value="9891436119">
								                                <label class="floatingLabel">mobile no./subscriber id</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="" readonly="readonly" value="AIB1199813A6">
							                                    <label class="floatingLabel">order id</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="" readonly="readonly" value="150">
							                                    <label class="floatingLabel">amount</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="name" readonly="readonly" value="ajay.gupta@canbrand.in">
							                                    <label class="floatingLabel">email</label>
							                                </div>
							                            </div>

							                            <div class="form_with-submit planBrowse newclass readonly-box pull-right">
							                                <div class="group">
							                                    <input type="text" required="" name="number" readonly="readonly" value="22/11/2016">
							                                    <label class="floatingLabel">date of transaction</label>
							                                </div>
							                                <div class="operator selectSubject position_rel escalate-subject">
																<label>Type of Problem</label>
															  	<button class="dropdown_button dropdown-toggle" type="button" id="selectSubject" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
															    Select
															    	<img src="assets/img/down-arrow.png">
																</button>
																<ul class="dropdown-menu animated fadeIn" aria-labelledby="selectSubject">
																   <li><a href="javascript:void(0)" data-value="action">Payment Deducted/Account not updated</a></li>
																   <li><a href="javascript:void(0)" data-value="another action">Payment Deducted/Session Timeout</a></li>
																</ul>
															</div>
							                                
							                                <div class="group">
							                                    <textarea placeholder="Comment"></textarea>
							                                </div>
							                                <div class="group">
							                                	<div class="enterCaptcha">
							                                		<span>Text <br>verification</span>
							                                		<figure><img src="assets/img/Captcha-ex.jpg"></figure>
							                                		<button><img src="assets/img/refresh.png" "=""></button>
							                                	</div>
							                                    <input class="modalInput" type="text" placeholder="Type the characters you see above" required="required">
							                                    <span class="highlight"></span>
							                                    <span class="error-msg">Characters you entered does not match.</span>
							                                </div>
							                            </div>
													</div>
													<div class="subBtn">
							                            <button type="button" id="ticketButton" data-toggle="modal" data-target="#success-msg">Submit</button>
							                        </div>
												</form>
											</div>
											<!--TICKET RAISE SUCCESS MESSAGE-->
											<div id="success-msg" class="modal fade successWrapper ticket-success" >
												<div class="modal-dialog">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">&times;</button>
														</div>
														<figure><img src="assets/img/Success.png"></figure>
														<h3>Submission Successful</h3>
														<div class="ticket-raise-wrapper">
															<ul class="head-title">
																<li>Your Ticket Number</li>
																<li>Date &amp; Time</li>
															</ul>
															<ul>
																<li>T50259309C6</li>
																<li>07th Aug'16 | 22:35 P.M.</li>
															</ul>
														</div>
														<p>
															Our customer support team will get back to you within 2 working days (excluding Sunday & Holidays) with a resolution. If you query is about refund, kindly note banks may take upto 7 days to credit the amount to account. In case your issue is not resolved in 8 days, you have an option to escalate any unresolved issue by choosing the escalation option in the choose subject field. 
														</p>
														<section class="thanks">
															<span>Thank You</span>
															<span>Team RechargeItNow</span>
														</section>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div id="profile" class="tab-pane profileUser fade in">
									<div class="zdasd clearfix">
										<div class="col-lg-6">
											<div class="personalDetail">
												<div class="detail-header">
													<h3><img src="assets/img/menu-profile.png">personal details</h3>
													<button><i class="fa fa-pencil" aria-hidden="true"></i></button>
												</div>
												<table>
													<tr>
														<td class="left">Name</td><td>Ajay Kumar Gupta</td>
													</tr>
													<tr>
														<td class="left">Email</td><td>ajay.gupta@canbrand.in</td>
													</tr>
													<tr>
														<td class="left">Gender</td><td>Male</td>
													</tr>
													<tr>
														<td class="left">Mobile No</td><td>+91 7065196404</td>
													</tr>
													<tr>
														<td class="left">Date of Birth</td><td>4th april 1990</td>
													</tr>
												</table>
											</div>
										</div>
									
										<div class="col-lg-6">
											<div class="personalDetail">
												<div class="detail-header">
													<h3><img src="assets/img/address-book.png">address book</h3>
													<button><i class="fa fa-pencil" aria-hidden="true"></i></button>
												</div>
												<div class="address">
													<div class="custName">
														<b>ajay kumar gupta</b>
														<button>office</button>
													</div>
													<div class="addDetails">
														<span>252 H, 3rd Floor, Kailash Plaza, Sant Nagar</span>
														<span>Easr of Kailash, Near Bikaner Sweets</span>
														<span>New Delhi - 110065</span>
													</div>
												</div>
												<div class="addAddress">
													<div class="addBtn">
														<button><span>Add Address</span><img src="assets/img/plus.png"></button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>

								<div id="password" class="tab-pane fade in">
									<form>
										<div class="form_with-submit changePasswordForm planBrowse newclass">
				                         	<div class="group">
												<input type="text" required="">
												<span class="highlight"></span>
												<span class="bar"></span>
												<label class="floatingLabel">old password</label>
				                          	</div>
				                          	<div class="group">
												<input type="text" required="">
												<span class="highlight"></span>
												<span class="bar"></span>
												<label class="floatingLabel">new password</label>
				                          	</div>
				                          	<div class="group zero-mb">
												<input type="text" required="">
												<span class="highlight"></span>
												<span class="bar"></span>
												<label class="floatingLabel">confirm password</label>
				                          	</div>
				                          	<div class="subBtn">
				                          		<button type="submit">Submit</button>
				                          	</div>
		                        		</div>
									</form>
								</div>
								<div id="help" class="tab-pane fade in">
									<div class="col-lg-12 help-tab">
										<p>
											My Account provides a consolidated view of your profile and transaction history with us. More importantly you can reach out to us for support or raising a query. Here is a list of features that can make your experience richer as you continue to recharge on India’s no. 1 recharge site:
										</p>
										<ul>
											<li><b>change password: </b>You can change your login password here. We suggest you refresh the password frequently to keep your transaction details secure.</li>
											<li><b>transaction history: </b>You can view all your past transactions at this location.</li>
											<li><b>ransaction history (old version): </b>You can view all your past transactions done using the old version of the website.</li>
											<li><b>view details: </b>You can get a detailed view of each transaction by selecting this option.</li>
											<li><b>open support ticket: </b>You can reach our customer support for help related to a specific transaction. you will need to select a transaction from your transaction history before clicking this option.</li>
											<li><b>escalate: </b>If your transaction related issue remains unresolved for 8 days, you can escalate it to us for a speedy response &amp; resolution.</li>
											<li><b>print: </b>You can take a print of your transaction or email the same to an email id of your choice.</li>
											<li><b>abort transaction: </b>In case the operator system is temporarily down, your transaction status will reflect ‘awaited.’ your transaction will be completed once the operator goes live. however, you have the option to abort the transaction in the interim. in case you abort the transaction, the refund will be processed within 2 working days. please note the bank may take upto 5 additional working days to credit the refund into your account.</li>
										</ul>
									</div>
								</div>
								<div id="sup" class="tab-pane fade in">
									<b>View All your pending tickets here</b>
									<p>
										You may escalate your issue if it remains unresolved for more than 7 days. Please note that you can escalate only after 7 days of your transaction date.
									</p>
									<ul class="col-lg-6">
										<li class="rechargeHistory activeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Ticket Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">Created On: 09th Dec'16, 14:17</span>
											</div>
											<div class="status">
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> 
												Resolved</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/docomo.png">
											</figure>
											<div class="rechargeId">
												<b>Ticket Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>8743990959</span></p>
												<span class="dateTime">Created On: 11th Nov'16, 05.26</span>
											</div>
											<div class="status">
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> 
												Resolved</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/docomo.png">
											</figure>
											<div class="rechargeId">
												<b>Ticket Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>9642698678</span></p>
												<span class="dateTime">Created On: 09th Sep'16, 11.12</span>
											</div>
											<div class="status">
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> 
												Resolved</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/airtel logo.png">
											</figure>
											<div class="rechargeId">
												<b>Ticket Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>7065196404</span></p>
												<span class="dateTime">Created On: 12th Dec'16, 00.15</span>
											</div>
											<div class="status">
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> 
												Resolved</span>
											</div>
										</li>
										<li class="rechargeHistory">
											<figure>
												<img src="assets/img/mob-operator/docomo.png">
											</figure>
											<div class="rechargeId">
												<b>Ticket Number: SD02387497A6</b>
												<p>Mob No/Subs ID: <span>8743990959</span></p>
												<span class="dateTime">Created On: 11th Nov'16, 05.26</span>
											</div>
											<div class="status">
												<span class="success"><i class="fa fa-check" aria-hidden="true"></i> 
												Resolved</span>
											</div>
										</li>
									</ul>
									<div class="col-lg-6 highlighted-Tab">
										<div class="indvidualDetails">
											<!-- <ul>
												<li><button class="escalate"><img src="assets/img/escalator.png"> escalate</button></li>
											</ul> -->
											<!--HISTORY DETAILS-->
											<table>
												
												<tr>
													<td>Ticket No.</td>
													<td class="bold">SD02387497A6</td>
												</tr>
												<tr>
													<td>Created On</td>
													<td class="bold">09-12-2016 | 14:17</td>
												</tr>
												<tr>
													<td>Mobile no./Subscriber ID</td>
													<td class="bold">7065196404</td>
												</tr>
												<tr>
													<td>Recharge/Bill pay amount</td><td class="bold">&#8377;280</td>
												</tr>
												<tr>
													<td>Recharge Date</td>
													<td class="bold">13-10-2016 | 12:57</td>
												</tr>
												<tr>
													<td>Query Type</td>
													<td class="bold">Escalation</td>
												</tr>
												<tr>
													<td>Status</td>
													<td class="bold">Closed</td>
												</tr>
												<tr>
													<td>Description</td>
													<td class="bold" style="text-align: justify;">
														Sample description text there are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.
													</td>
												</tr>
											</table>
											<div id="support_escalate_button" class="subBtn">
					                            <button type="button">Escalate</button>
					                        </div>
											<div id="support_escalate">
												<div class="ticket-comment-box">
													<!-- <label>Any Query</label> -->
					                                <textarea placeholder="Write your query here..."></textarea>
					                            </div>
					                            <div class="subBtn">
						                            <button type="button" id="ticketButton">Submit</button>
						                        </div>
					                        </div>
			                                
											<!--OPEN SUPPORT TICKET-->
											<div class="contactPage customeSelect selectWithLabel mobSelectMbd" id="open-support">
												<p>
													You may escalate your issue if it remains unresolved for more than 7 days. Please note that you can escalate only after 7 days of your transaction date.
												</p>
												<form class="escalate-form">
													<div class="userSecondInput">
														<div class="form_with-submit planBrowse newclass readonly-box">
															<div class="operator selectService position_rel escalate-subject">
																<label>Choose Subject</label>
															  	<button class="dropdown_button dropdown-toggle" type="button" id="selectService" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
															    Select
															    	<img src="assets/img/down-arrow.png">
																</button>
																<ul class="dropdown-menu animated fadeIn" aria-labelledby="selectService">
																	<li><a href="javascript:void(0)" data-value="action">Escalation</a></li>
																	<li><a href="javascript:void(0)" data-value="another action">Payment not Updated</a></li>
																	
																</ul>
															</div>
							                                <div class="group">
							                                    <input type="text" required="" name="name" value="Ajay Gupta" readonly="readonly">
							                                    <label class="floatingLabel">name</label>
							                                </div>
							                                <div class="group">
							                                   	<input type="text" required="" name="number" readonly="readonly" value="7065196404">
							                                   	<label class="floatingLabel">contact mobile number</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="" readonly="readonly" value="9891436119">
								                                <label class="floatingLabel">mobile no./subscriber id</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="" readonly="readonly" value="AIB1199813A6">
							                                    <label class="floatingLabel">order id</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="" readonly="readonly" value="150">
							                                    <label class="floatingLabel">amount</label>
							                                </div>
							                                <div class="group">
							                                    <input type="text" required="" name="name" readonly="readonly" value="ajay.gupta@canbrand.in">
							                                    <label class="floatingLabel">email</label>
							                                </div>
							                            </div>

							                            <div class="form_with-submit planBrowse newclass readonly-box pull-right">
							                                <div class="group">
							                                    <input type="text" required="" name="number" readonly="readonly" value="22/11/2016">
							                                    <label class="floatingLabel">date of transaction</label>
							                                </div>
							                                <div class="operator selectSubject position_rel escalate-subject">
																<label>Type of Problem</label>
															  	<button class="dropdown_button dropdown-toggle" type="button" id="selectSubject" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
															    Select
															    	<img src="assets/img/down-arrow.png">
																</button>
																<ul class="dropdown-menu animated fadeIn" aria-labelledby="selectSubject">
																   <li><a href="javascript:void(0)" data-value="action">Payment Deducted/Account not updated</a></li>
																   <li><a href="javascript:void(0)" data-value="another action">Payment Deducted/Session Timeout</a></li>
																</ul>
															</div>
							                                
							                                <div class="group">
							                                    <textarea placeholder="Comment"></textarea>
							                                </div>
							                                <div class="group">
							                                	<div class="enterCaptcha">
							                                		<span>Text <br>verification</span>
							                                		<figure><img src="assets/img/Captcha-ex.jpg"></figure>
							                                		<button><img src="assets/img/refresh.png" "=""></button>
							                                	</div>
							                                    <input class="modalInput" type="text" placeholder="Type the characters you see above" required="required">
							                                    <span class="highlight"></span>
							                                    <span class="error-msg">Characters you entered does not match.</span>
							                                </div>
							                            </div>
													</div>
													<div class="subBtn">
							                            <button type="button" id="ticketButton" data-toggle="modal" data-target="#success-msg">Submit</button>
							                        </div>
												</form>
											</div>
											<!--TICKET RAISE SUCCESS MESSAGE-->
											<div id="success-msg" class="modal fade successWrapper ticket-success" >
												<div class="modal-dialog">
													<div class="modal-content">
														<div class="modal-header">
															<button type="button" class="close" data-dismiss="modal">&times;</button>
														</div>
														<figure><img src="assets/img/Success.png"></figure>
														<h3>Submission Successful</h3>
														<div class="ticket-raise-wrapper">
															<ul class="head-title">
																<li>Your Ticket Number</li>
																<li>Date &amp; Time</li>
															</ul>
															<ul>
																<li>T50259309C6</li>
																<li>07th Aug'16 | 22:35 P.M.</li>
															</ul>
														</div>
														<p>
															Our customer support team will get back to you within 2 working days (excluding Sunday & Holidays) with a resolution. If you query is about refund, kindly note banks may take upto 7 days to credit the amount to account. In case your issue is not resolved in 8 days, you have an option to escalate any unresolved issue by choosing the escalation option in the choose subject field. 
														</p>
														<section class="thanks">
															<span>Thank You</span>
															<span>Team RechargeItNow</span>
														</section>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					<!--MOBILE ACCORDION-->
					<div class="mobile-view">
						<div class="mobile-accordion-wrapper">
							<button class="accordion">transaction history</button>
							<div class="panel-custom">
								<ul>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Airtel</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Jio</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Airtel</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Idea</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Docomo</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Relience</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
									<li class="rechargeHistory activeHistory">
										<span class="op-name">Vodafone</span>
										<div class="rechargeId">
											<b>#SD02387497A6</b>
											<p>Mob No/Subs ID: <span>7065196404</span></p>
											<span class="dateTime">07th Aug'16, 00.15</span>
										</div>
										<div class="status">
											<b>&#8377; 700</b>
											<span class="success"><i class="fa fa-check" aria-hidden="true"></i> Success</span>
										</div>
									</li>
								</ul>
							</div>
							<button class="accordion">profile</button>
							<div class="panel-custom">
								<div class="personalDetail">
											<div class="detail-header">
												<h3><img src="assets/img/menu-profile.png">personal details</h3>
												<button><i class="fa fa-pencil" aria-hidden="true"></i></button>
											</div>
											<table>
												<tr>
													<td class="left">Name</td><td>Ajay Kumar Gupta</td>
												</tr>
												<tr>
													<td class="left">Email</td><td>ajay.gupta@canbrand.in</td>
												</tr>
												<tr>
													<td class="left">Gender</td><td>Male</td>
												</tr>
												<tr>
													<td class="left">Mobile No</td><td>+91 7065196404</td>
												</tr>
												<tr>
													<td class="left">Date of Birth</td><td>4th april 1990</td>
												</tr>
											</table>
								</div>
								<div class="personalDetail">
									<div class="detail-header">
										<h3><img src="assets/img/address-book.png">address book</h3>
										<button><i class="fa fa-pencil" aria-hidden="true"></i></button>
									</div>
									<div class="address">
										<div class="custName">
											<b>ajay kumar gupta</b>
											<button>office</button>
										</div>
										<div class="addDetails">
											<span>252 H, 3rd Floor, Kailash Plaza, Sant Nagar</span>
											<span>Easr of Kailash, Near Bikaner Sweets</span>
											<span>New Delhi - 110065</span>
										</div>
									</div>
									<div class="addAddress">
										<div class="addBtn">
											<button><span>Add Address</span><img src="assets/img/plus.png"></button>
										</div>
									</div>
								</div>
							</div>
							<button class="accordion">change password</button>
							<div class="panel-custom">
								<form class="accordion-form">
										<div class="form_with-submit planBrowse newclass">
				                         	<div class="group">
												<input type="text" required="">
												<span class="highlight"></span>
												<span class="bar"></span>
												<label class="floatingLabel accordio-label">old password</label>
				                          	</div>
				                          	<div class="group">
												<input type="text" required="">
												<span class="highlight"></span>
												<span class="bar"></span>
												<label class="floatingLabel accordio-label">new password</label>
				                          	</div>
				                          	<div class="group zero-mb">
												<input type="text" required="">
												<span class="highlight"></span>
												<span class="bar"></span>
												<label class="floatingLabel accordio-label">confirm password</label>
				                          	</div>
				                          	<div class="subBtn">
				                          		<button type="submit">Submit</button>
				                          	</div>
		                        		</div>
								</form>
							</div>
							<button class="accordion">view tickets</button>
							<div class="panel-custom">
								Coming Soon...
							</div>
							<button class="accordion">Escalation</button>
							<div class="panel-custom">
								<div class="col-lg-12 contactPage customeSelect selectWithLabel mobSelectMb">
										<p>
											You may escalate your issue if it remains unresolved for more than 7 days. Please note that you can escalate only after 7 days of your transaction date.
										</p>
										<form class="escalate-form">
											<div class="userSecondInput">
												<div class="form_with-submit planBrowse newclass readonly-box">
													<div class="operator selectService position_rel escalate-subject">
														<label>Choose Subject</label>
													  	<button class="dropdown_button dropdown-toggle" type="button" id="selectService" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
													    Escalation
													    	<img src="assets/img/down-arrow.png">
														</button>
														<ul class="dropdown-menu animated fadeIn" aria-labelledby="selectService">
															<li><a href="javascript:void(0)" data-value="action">Escalation</a></li>
															<li><a href="javascript:void(0)" data-value="another action">Failed Recharge</a></li>
															<li><a href="javascript:void(0)" data-value="another action">Query/Feedback</a></li>
															<li><a href="javascript:void(0)" data-value="another action">Recharge Coupon</a></li>
															<li><a href="javascript:void(0)" data-value="another action">Partner Discount Coupon</a></li>
															<li><a href="javascript:void(0)" data-value="another action">Advertisement Enquiries</a></li>
														</ul>
													</div>
					                                <div class="group">
					                                    <input type="text" required="" name="name" value="Ajay Gupta" readonly="readonly">
					                                    <label class="floatingLabel">name</label>
					                                </div>
					                                <div class="group">
					                                   	<input type="text" required="" name="number" readonly="readonly" value="7065196404">
					                                   	<label class="floatingLabel">contact mobile number</label>
					                                </div>
					                                <div class="group">
					                                    <input type="text" required="" name="" readonly="readonly" value="9891436119">
						                                <label class="floatingLabel">mobile no./subscriber id</label>
					                                </div>
					                                <div class="group">
					                                    <input type="text" required="" name="" readonly="readonly" value="AIB1199813A6">
					                                    <label class="floatingLabel">order id</label>
					                                </div>
					                                <div class="group">
					                                    <input type="text" required="" name="" readonly="readonly" value="150">
					                                    <label class="floatingLabel">amount</label>
					                                </div>
					                                <div class="group">
					                                    <input type="text" required="" name="name" readonly="readonly" value="ajay.gupta@canbrand.in">
					                                    <label class="floatingLabel">email</label>
					                                </div>
					                            </div>

					                            <div class="form_with-submit planBrowse newclass readonly-box pull-right">
					                                <div class="group">
					                                    <input type="text" required="" name="number" readonly="readonly" value="22/11/2016">
					                                    <label class="floatingLabel">date of transaction</label>
					                                </div>
					                                <div class="operator selectSubject position_rel escalate-subject">
														<label>Type of Problem</label>
													  	<button class="dropdown_button dropdown-toggle" type="button" id="selectSubject" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
													    SELECT
													    	<img src="assets/img/down-arrow.png">
														</button>
														<ul class="dropdown-menu animated fadeIn" aria-labelledby="selectSubject">
														   <li><a href="javascript:void(0)" data-value="action">Failed Recharge</a></li>
														   <li><a href="javascript:void(0)" data-value="another action">Escalation</a></li>
														   <li><a href="javascript:void(0)" data-value="another action">Recharge Coupon</a></li>
														</ul>
													</div>
					                                
					                                <div class="group">
					                                    <textarea placeholder="Comment"></textarea>
					                                </div>
					                                <div class="group">
					                                	<div class="enterCaptcha">
					                                		<span>Text <br>verification</span>
					                                		<figure><img src="assets/img/Captcha-ex.jpg"></figure>
					                                		<button><img src="assets/img/refresh.png" "=""></button>
					                                	</div>
					                                    <input class="modalInput" type="text" placeholder="Type the characters you see above" required="">
					                                    <span class="highlight"></span>
					                                    <span class="error-msg">Characters you entered does not match.</span>
					                                </div>
					                            </div>
											</div>
											<div class="subBtn">
					                            <button type="submit">Submit</button>
					                        </div>
										</form>
									</div>
							</div>
							<button class="accordion">Help</button>
							<div class="panel-custom">
								<div class="col-lg-12 help-tab">
										
										<p>
											My Account provides a consolidated view of your profile and transaction history with us. More importantly you can reach out to us for support or raising a query. Here is a list of features that can make your experience richer as you continue to recharge on India’s no. 1 recharge site:
										</p>
										<ul>
											<li><b>change password: </b>You can change your login password here. We suggest you refresh the password frequently to keep your transaction details secure.</li>
											<li><b>transaction history: </b>You can view all your past transactions at this location.</li>
											<li><b>ransaction history (old version): </b>You can view all your past transactions done using the old version of the website.</li>
											<li><b>view details: </b>You can get a detailed view of each transaction by selecting this option.</li>
											<li><b>open support ticket: </b>You can reach our customer support for help related to a specific transaction. you will need to select a transaction from your transaction history before clicking this option.</li>
											<li><b>escalate: </b>If your transaction related issue remains unresolved for 8 days, you can escalate it to us for a speedy response &amp; resolution.</li>
											<li><b>print: </b>You can take a print of your transaction or email the same to an email id of your choice.</li>
											<li><b>abort transaction: </b>In case the operator system is temporarily down, your transaction status will reflect ‘awaited.’ your transaction will be completed once the operator goes live. however, you have the option to abort the transaction in the interim. in case you abort the transaction, the refund will be processed within 2 working days. please note the bank may take upto 5 additional working days to credit the refund into your account.</li>
										</ul>
									</div>
							</div>
						</div>
					</div>
					<!--CUSTOMER-ACCOUNT-BODY END-->
					</div>
				</div>
			</div>
			<!--CUSTOMER ACCOUNT DETAIL PAGE END-->
			<!--GOOGLE-ADVERTISE-RIGHT-SIDE START-->
 			<div class="advertise hidden-xs hidden-xs">
				<ul>
					<li><img src="assets/img/side-img-1.jpg"></li>
					<li><img src="assets/img/side-img-2.jpg"></li>
				</ul>
			</div>
			<!--GOOGLE-ADVERTISE-RIGHT-SIDE END-->

			
 		</div>
	</section>
</div>
<!--********************************CONTENT PART END**********************************-->
 <?php include_once 'footer.php'; ?>
