 <section id="billPayment">
              <div class="container">
                <div class="row">
                  <div class="col-lg-8">
                    <div class="textArea">
                      <h2>Online Recharge for Prepaid Mobile, DTH &amp; Data Cards and Postpaid Bill Payment</h2>
                      <p>
                        India's No.1 Online Recharge &amp; Postpaid Bill Payment Site. One stop solution for all prepaid mobile recharge, DTH recharge &amp; Data Card recharge and Online Bill Payment needs. Get instant and easy online recharge for Airtel, Vodafone, Idea, BSNL, Aircel, Tata Docomo CDMA, Tata Docomo GSM, Tata Indicom Delhi, MTNL Trump Mumbai, MTNL Trump Delhi, MTS, Reliance CDMA, Reliance GSM, T24, Telenor, Videocon.
                      </p>
                      <p>
                        mobile for all circles across India. Online Dth recharge for Tata Sky, Airtel Digital TV, Dish TV, Reliance Digital TV, Sun Direct &amp; Videocon D2H. We provide convenient way to recharge prepaid mobile and DTH using credit card / debit card / net banking / IMPS and Airtel Money. Get a quick, easy and secure recharge using detailed recharge plans, every time, anytime from your mobile or desktop.
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <figure class="imgArea">
                      <img src="assets/img/pay-now.png">
                    </figure>
                  </div>
                </div>
              </div>
            </section>