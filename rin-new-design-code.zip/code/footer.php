
<footer>
<a href="#" id="scroll" title="Scroll to Top" style="display: none;">Top<span></span></a>
            <section id="footerSection">

            <div class="container">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="listHeader line">
                                <b>Mobile Recharge</b>
                            </div>
                            <ul class="rechargeList line">
                                <li><a href="recharge.php">Airtel</a></li>
                                <li><a href="recharge.php">Aircel</a></li>
                                <li><a href="recharge.php">Vodafone</a></li>
                                <li><a href="recharge.php">BSNL</a></li>
                                <li><a href="recharge.php">Tata Docomo CDMA</a></li>
                                <li><a href="recharge.php">Idea</a></li>
                                <li><a href="recharge.php">Tata Docomo GSM</a></li>
                                <li><a href="recharge.php">MTNL Trump Mumbai</a></li>
                                <li><a href="recharge.php">MTNL Trump Delhi</a></li>
                                <li><a href="recharge.php">Reliance CDMA</a></li>
                                <li><a href="recharge.php">Telenor</a></li>
                                <li><a href="recharge.php">Reliance GSM</a></li>
                                <li><a href="recharge.php">MTS</a></li>
                                <li><a href="recharge.php">Tata Indicom Delhi</a></li>
                                <li><a href="recharge.php">Videocon</a></li>
                                <li><a href="recharge.php">T24</a></li>
                                <li><a href="recharge.php">Tata Walky</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-2">
                            <div class="listHeader line">
                                <b>DTH Recharge</b>
                            </div>
                            <ul class="rechargeList line">
                                <li><a href="">Airtel Digital TV</a></li>
                                <li><a href="">Reliance Digital TV</a></li>
                                <li><a href="">Dish TV</a></li>
                                <li><a href="">Tata Sky</a></li>
                                <li><a href="">Sun Direct</a></li>
                                <li><a href="">Videocon D2H</a></li>
                                
                            </ul>
                        </div>
                        <div class="col-lg-4">
                            <div class="listHeader line">
                                <b>Data Card Recharge</b>
                            </div>
                            <div class="doubleUl line">
                                <ul class="rechargeList">
                                    <li><a href="">Airtel</a></li>
                                    <li><a href="">Airtel 2G Service</a></li>
                                    <li><a href="">Airtel 3G Service</a></li>
                                    <li><a href="">Aircel</a></li>
                                    <li><a href="">Aircel 2G Service</a></li>
                                    <li><a href="">Aircel 3G Service</a></li>
                                    <li><a href="">Vodafone</a></li>
                                    <li><a href="">Vodafone 2G Service</a></li>
                                    <li><a href="">Vodafone 3G Service</a></li>
                                    <li><a href="">BSNL</a></li>
                                    <li><a href="">BSNL 3G Service</a></li>
                                    <li><a href="">Idea</a></li>
                                    <li><a href="">Idea 2G Service</a></li>
                                    <li><a href="">Idea 3G Service</a></li>
                                    <li><a href="">MTNL Mumbai</a></li>
                                    <li><a href="">MTNL Delhi</a></li>
                                    <li><a href="">MTNL Delhi 3G Service</a></li>
                                </ul>
                                <ul class="rechargeList">
                                    <li><a href="">MTS</a></li>
                                    <li><a href="">MTS 3G Service</a></li>
                                    <li><a href="">Reliance CDMA</a></li>
                                    <li><a href="">Reliance CDMA 2G Service</a></li>
                                    <li><a href="">Reliance CDMA 3G Service</a></li>
                                    <li><a href="">Reliance GSM</a></li>
                                    <li><a href="">Reliance GSM 3G Service</a></li>
                                    <li><a href="">T24</a></li>
                                    <li><a href="">T24 3G Service</a></li>
                                    <li><a href="">Tata Indicom Delhi</a></li>
                                    <li><a href="">Tata Docomo CDMA</a></li>
                                    <li><a href="">Tata Docomo 3G Service</a></li>
                                    <li><a href="">Tata Docomo GSM</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="listHeader line">
                                <b>Bill Pay - Mobile &amp; Data</b>
                            </div>
                            <ul class="rechargeList line">
                                <li><a href="">Airtel</a></li>
                                <li><a href="">Airtel Landline/DSL</a></li>
                                <li><a href="">Aircel</a></li>
                                <li><a href="">Vodafone</a></li>
                                <li><a href="">BSNL</a></li>
                                <li><a href="">Tata Docomo CDMA</a></li>
                                <li><a href="">Idea</a></li>
                                <li><a href="">MTS</a></li>
                                <li><a href="">Tata Docomo GSM</a></li>
                                <li><a href="">Tata Indicom Delhi</a></li>
                                <li><a href="">Reliance CDMA</a></li>
                                <li><a href="">Reliance GSM</a></li>
                                
                            </ul>
                        </div>
                        <div class="col-lg-2">
                        <div class="listHeader">
                                <b>RechargeItNow</b>
                            </div>
                            <ul class="rechargeList">
                                <li><a href="about.php">About Us</a></li>
                                <li><a href="contactus.php">Contact Us</a></li>
                                <li><a href="services.php">Service</a></li>
                                <li><a href="how-to-use.php">How to Use</a></li>
                                <li><a href="refund-policy.php">Refund Policy</a></li>
                                <li><a href="coupons.php">Coupons</a></li>
                                <li><a href="plans-schemes.php">Plans &amp; Schemes</a></li>
                                <li><a href="faq.php">Faq</a></li>
                                <li><a href="disclaimer.php">Disclaimer</a></li>
                                <li><a href="sitemap.php">Sitemap</a></li>
                                <li><a href="terms.php">Terms of Usage</a></li>
                                <li><a href="privacy.php">Privacy Policy Updated</a></li>
                                <li><a href="">Discount Coupon</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
            <section class="social">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-sm-6 footerDivider">
                            <div class="footerBottom">
                                <h2>Download App</h2>
                                <div class="rechargeApp">
                                    <ul>
                                        <li><a href=""><img src="assets/img/google_store.png"></a></li>
                                        <li><a href=""><img src="assets/img/apple_store.png"></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 footerDivider">
                            <div class="footerBottom">
                                <h2>Login</h2>
                                <div class="socialLinks">
                                    <ul>
                                        <li><a href=""><img src="assets/img/social/footer-yahoo.png"></a></li>
                                        <li><a href=""><img src="assets/img/social/footer-linkedin.png"></a></li>
                                        <li><a href=""><img src="assets/img/social/footer-facebook.png"></a></li>
                                        <li><a href=""><img src="assets/img/social/footer-google.png"></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6">
                            <div class="footerBottom">
                                <h2>Secured By</h2>
                                <div class="card">
                                    <ul>
                                        <li><a href=""><img src="assets/img/footer-master.png"></a></li>
                                        <li><a href=""><img src="assets/img/footer-visa.png"></a></li>
                                        <li><a href=""><img src="assets/img/footer-geotrust.png"></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
                
            </section>
            <?php
                if(basename($_SERVER['PHP_SELF']) != 'screen_fourth.php'){
                ?>
                    <section id="offerBanner" class="hidden-sm hidden-md hidden-lg">
                        <figure><img src="assets/img/googlead_mobile.png"></figure>
                    </section>
            <?php } ?>

            <section class="copy-right">
                <p>All rights reserved with Online Recharge Services Pvt. Ltd.</p>
            </section>

         </footer>
         <!--FOOTER END-->
   </div>
   <!--END PAGE WRAPPER--> 
</body>

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBieeml97FXjn_qxV--10bgar_TyCMrWIs&libraries=places"></script>
<script src="assets/js/jquery.placepicker.js"></script>
<script src="assets/js/jquery.maskedinput.js"></script>
<script src="assets/js/formValidation.js"></script>
<script src="assets/js/jquery.autocomplete.min.js"></script>
<script src="assets/js/currency-autocomplete.js"></script>
<script src="assets/js/jquery-ui.min.js"></script>
<script src="assets/js/custom.js"></script>
<script src="assets/js/custom-dd.js"></script>

<script>
    $(function () {
        $(document).ready(function(){
            <?php
            for($i = 1; $i < 10; $i++){
                ?>
                    $('#banktool_<?php echo $i;?>').mouseover(function(){
                        $('#banktooltip_<?php echo $i;?>').show();
                    });
                    $('#banktool_<?php echo $i;?>').mouseout(function(){
                        $('#banktooltip_<?php echo $i;?>').hide();
                    });
                <?php
            }
            ?>
        });
    });
</script>

</html>