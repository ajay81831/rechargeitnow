<section id="allOperators">
              <div class="container">
                <div class="row">
                <div class="col-lg-12">
                  <h2>Recharges and Bill Payments Available for All Operators</h2>
                </div>
                  
                </div>
                <div class="row">
                  <div class="col-lg-8 mobMB">
                    <h3>Telecom</h3>
                    <div class="mobileOperatorList">
                      <ul>
                        <li><a href=""><img src="assets/img/mob-operator/airtel logo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/docomo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/reliance.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/Jio-Logo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/index.jpg"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/LSIM-CA04_200px.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/MTNL-Logo-1.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/reliance.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/airtel logo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/docomo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/reliance.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/Jio-Logo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/index.jpg"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/LSIM-CA04_200px.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/MTNL-Logo-1.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/reliance.png"></a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-lg-1"></div>
                  <div class="col-lg-3">
                    <h3>Digital TV</h3>
                    <div class="mobileOperatorList">
                      <ul>
                        <li><a href=""><img src="assets/img/mob-operator/airtel logo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/docomo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/reliance.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/airtel logo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/docomo.png"></a></li>
                        <li><a href=""><img src="assets/img/mob-operator/reliance.png"></a></li>
                        
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </section>