<ul class="nav nav-pills verticalMenu newTest hidden-xs">

    <li class="active"><a data-toggle="pill" href="#mobile"> <img src="assets/img/menu-icons/mobile-nav.png"><span>Mobile</span></a></li>
    <span class="border hidden-xs"></span>
    <li><a data-toggle="pill" href="#jio"><img src="assets/img/menu-icons/jio-nav.png"><span>jio reliance</span></a></li>
    <span class="border hidden-xs"></span>
    <li><a data-toggle="pill" href="#datacard"><img src="assets/img/menu-icons/data-card-nav.png"><span>Data Card</span></a></li>
    <span class="border hidden-xs"></span>
    <li><a data-toggle="pill" href="#dth"><img src="assets/img/menu-icons/dth-nav.png"><span>DTH</span></a></li>
    <span class="border hidden-xs"></span>
    
    <li><a data-toggle="pill" href="#gas"><img src="assets/img/menu-icons/gas-nav.png"><span>Gas</span></a></li>
    <div class="bannerAppSection hidden-xs hidden-sm">
    	<h3>download our apps</h3>
    	<a href=""><img src="assets/img/google_store.png"></a>
    	<a href=""><img src="assets/img/apple_store.png"></a>
    </div>

</ul>

<div class="tabHead-mobile mobileScrollheader hidden-sm hidden-md hidden-lg">
    <div class="box-outer">
      <a class="arrow-left arrow hidden-lg hidden-md hidden-sm "><img src="assets/img/angle-pointing-to-left.png"></a>
      <a class="arrow-right arrow hidden-lg hidden-md hidden-sm"><img src="assets/img/angle-arrow-pointing-to-right.png"></a>
      <div class="box-inner">
        <ul class="nav nav-tabs tabs-left box-inner" id="plansNav">
            <li class="active">
                <a href="#mobile" data-toggle="tab"><img src="assets/img/menu-icons/mobile-nav.png"><span>Mobile</span></a>
            </li>
            <li>
                <a href="#jio" data-toggle="tab"><img src="assets/img/menu-icons/jio-nav.png"><span>Jio Relience</span></a>
            </li>
            <li>
                <a href="#datacard" data-toggle="tab"><img src="assets/img/menu-icons/data-card-nav.png"><span>Data Card</span></a>
            </li>
            <li>
                <a href="#dth" data-toggle="tab"><img src="assets/img/menu-icons/dth-nav.png"><span>DTH</span></a>
            </li>
            <li>
               <a href="#gas" data-toggle="tab"><img src="assets/img/menu-icons/gas-nav.png"><span>Gas</span></a>
            </li>
            <!-- <li>
                <a href="#mobile" data-toggle="tab"><img src="assets/img/menu-icons/mobile-nav.png">Mobile</a>
            </li>
            <li>
                <a href="#mobile" data-toggle="tab"><img src="assets/img/menu-icons/mobile-nav.png">Mobile</a>
            </li> -->
        </ul>
    </div>
    </div>
</div>