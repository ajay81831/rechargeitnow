<section id="downloadSection">
  <div class="container">
    <div class="row">
      <div class="col-lg-8">
        <div class="textArea">
          <h2>Download Our Mobile App!</h2>
          <p>
            India's No.1 Online Recharge &amp; Postpaid Bill Payment Site. One stop solution for all prepaid mobile recharge, DTH recharge &amp; Data Card recharge and Online Bill Payment needs. Get instant and easy online recharge for Airtel, Vodafone, Idea, BSNL, Aircel, Tata Docomo CDMA, Tata Docomo GSM, Tata Indicom Delhi, MTNL Trump Mumbai, MTNL Trump Delhi, MTS, Reliance CDMA, Reliance GSM, T24, Telenor, Videocon.
          </p>
          <p>
            mobile for all circles across India. Online Dth recharge for Tata Sky, Airtel Digital TV, Dish TV, Reliance Digital TV, Sun Direct &amp; Videocon D2H. 
          </p>
          <div class="productApp">
            <ul>
              <li><a href=""><img src="assets/img/google_store.png"></a></li>
              <li class="or">or</li>
              <li><a href=""><img src="assets/img/apple_store.png"></a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
      <div class="mobileImage">
        <figure class="downLoadMob">
          <img src="assets/img/mobile-2.png">
        </figure>
        </div>
      </div>
    </div>
  </div>
</section>