<section class="fullSection">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 pull-right">
        <figure class="imgArea">
          <img src="assets/img/voda-sideimage.png">
        </figure>
      </div>
      <div class="col-lg-8 pull-right">
        <div class="textArea">
          <h2>Vodafone Online Prepaid Mobile Recharge</h2>
          <p>
            Rechargeitnow.com is India&apos;s first and largest online rechrge site that delivers 100% secure and instant online recharge for prepaid mobiles, DTH and data cards &amp; postpaid mobile bill payment solutions.

            India's No.1 Online Recharge &amp; Postpaid Bill Payment Site. One stop solution for all prepaid mobile recharge, DTH recharge &amp; Data Card recharge and Online Bill Payment needs. Get instant and easy online recharge for Airtel, Vodafone, Idea, BSNL, Aircel, Tata Docomo CDMA, Tata Docomo GSM, Tata Indicom Delhi, MTNL Trump Mumbai, MTNL Trump Delhi, MTS, Reliance CDMA, Reliance GSM, T24, Telenor, Videocon.
          </p>
          
        </div>
      </div>
      
    </div>
  </div>
</section>